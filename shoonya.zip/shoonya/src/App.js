import './App.css';

import Header from './components/Header';
import Info from './components/Info';
import Retreats from './components/Retreats';

function App() {
  return (
    <div className="app">
      <Header />
      <Info />
      <Retreats />
    </div>


  );
}

export default App;
