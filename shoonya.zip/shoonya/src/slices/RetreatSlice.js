import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const retreatList = createAsyncThunk('retreatList', async (_, { rejectWithValue }) => {
    try {
        const response = await axios.get('https://669f704cb132e2c136fdd9a0.mockapi.io/api/v1/retreats');
        //console.log(response.data);
        return response.data;
    } catch (error) {
        return rejectWithValue(error);
    }
})

export const searchByTitle = createAsyncThunk('searchRetreatList', async (filterValues, rejectWithValue) => {
    //console.log(filterValues);
    const { searchTerm, filterByDate, filterByType, filterByLocation, filterByPrice } = filterValues;

    try {
        const { data } = await axios.get(`https://669f704cb132e2c136fdd9a0.mockapi.io/api/v1/retreats?title=${searchTerm}`);
        let list = [...data];

        if (filterByDate) {
            const compareDate = filterByDate === '2023' ? 2023 : 2024;
            list = list.filter(retreat => new Date(retreat.date * 1000).getFullYear() === compareDate);
        }

        if (filterByType) {
            list = list.filter(retreat => retreat.type === filterByType);
        }

        if (filterByPrice) {
            list = list.sort((a, b) => filterByPrice === 'low to high' ? a.price - b.price : b.price - a.price);
        }

        if (filterByLocation) {
            list = list.filter(retreat => retreat.location.toLowerCase() === filterByLocation.toLowerCase());
        }
        return list;

    } catch (error) {
        return rejectWithValue(error.response ? error.response.data.message : error.message);
    }

})

const retreatSlice = createSlice({
    name: 'retreatSlice',
    initialState: {
        totalRetreatList: [],
        filterRetreatList: [],
        retreatLength: null,
        isLoading: false,
        error : null
    },
    reducers: {
        filterData: (state, action) => {
            const { filterByDate, filterByType, filterByLocation, filterByPrice } = action.payload;
            let list = [...state.totalRetreatList];

            if (filterByDate) {
                const compareDate = filterByDate === '2023' ? 2023 : 2024;
                list = list.filter(retreat => new Date(retreat.date * 1000).getFullYear() === compareDate);
            }

            if (filterByType) {
                list = list.filter(retreat => retreat.type === filterByType);
            }

            if (filterByPrice) {
                list = list.sort((a, b) => filterByPrice === 'low to high' ? a.price - b.price : b.price - a.price);
            }

            if (filterByLocation) {
                list = list.filter(retreat => retreat.location.toLowerCase() === filterByLocation.toLowerCase());
            }

            //console.log(JSON.stringify(list, null, 2));

            state.filterRetreatList = list;
            state.retreatLength = state.filterRetreatList.length;

        }

    },
    extraReducers: (builder) => {
        builder.addCase(retreatList.pending, (state) => {
            state.isLoading = true;
        }).addCase(retreatList.fulfilled, (state, action) => {
            state.filterRetreatList = action.payload;
            state.totalRetreatList = action.payload;
            state.retreatLength = action.payload.length;
            state.isLoading = false;
            state.error = null;
        }).addCase(retreatList.rejected, (state, action) => {
            state.error = action.payload;
            state.isLoading = false;
        }).addCase(searchByTitle.pending, (state) => {
            state.error = null;
        }).addCase(searchByTitle.fulfilled, (state, action) => {
            state.filterRetreatList = action.payload;
            state.retreatLength = action.payload.length;
            state.error = null;
        }).addCase(searchByTitle.rejected, (state, action) => {
            state.error = action.payload;
        })
    }
})

export const { filterData } = retreatSlice.actions;

export default retreatSlice.reducer;