import {configureStore} from '@reduxjs/toolkit';
import retreatSlice from './slices/RetreatSlice';

const store = configureStore({
    reducer : {
        retreat : retreatSlice
    }
})

export default store;