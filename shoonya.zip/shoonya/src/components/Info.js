import './Info.css';




function Info() {

    return (

        <div className="info">
                    <div className="info-img">

                    </div>
                    <div className="info-text">
                        <span className="info-text1">Discover Your Inner Peace</span> <br></br>
                        <span className="info-text2 pt-2">Join us for a series of wellness retreats designed to help you find tranquility and rejuvenation.</span>
                    </div>
        </div>
    )
}

export default Info;