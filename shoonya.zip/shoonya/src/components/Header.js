import './Header.css';

function Header() {

    return (
        <div className="header">
            <p className="header_text">Wellness Retreats</p>
        </div>
    )
}

export default Header;