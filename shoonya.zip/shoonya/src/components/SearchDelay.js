import { useState, useEffect } from 'react';

function SearchDelay(value, delay){
    const [delayValue, setDelayValue] = useState(value);

  useEffect(() => {
    const handler = setTimeout(() => {
        setDelayValue(value);
    }, delay);

    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);

  return delayValue;
}

export default SearchDelay;