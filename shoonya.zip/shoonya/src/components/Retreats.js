import './Retreats.css';
import { useState, useEffect } from 'react';
import React from 'react';
import RetreatInfo from './RetreatInfo';
import { useDispatch, useSelector } from 'react-redux';
import { retreatList, searchByTitle, filterData } from '../slices/RetreatSlice';
import SearchDelay from './SearchDelay';

function Retreats() {

    const { filterRetreatList, retreatLength, isLoading, error } = useSelector(state => state.retreat);
    const dispatch = useDispatch();

    const [pageNumber, setPageNumber] = useState(1);
    const [retreatCountPerPage, setRetreatCountPerPage] = useState(3);

    const lastRetreatIndexofCurrentPage = pageNumber * retreatCountPerPage;
    const firstRetreatIndexofCurrentPage = lastRetreatIndexofCurrentPage - retreatCountPerPage;
    const retreatsPerPage = filterRetreatList.slice(firstRetreatIndexofCurrentPage, lastRetreatIndexofCurrentPage);

    useEffect(() => {
        dispatch(retreatList());
    }, [dispatch]);

    const togglePreviousPage = () => {
        if (pageNumber > 1) {
            setPageNumber(pageNumber - 1);
        }
    }

    const toggleNextPage = () => {
        if (lastRetreatIndexofCurrentPage < retreatLength) {
            setPageNumber(pageNumber + 1);
        }
    }

    const [filterValues, setFilterValues] = useState({
        filterByDate: '',
        filterByType: '',
        filterByLocation: '',
        filterByPrice: ''
    });

    const [searchFilter, setSearchFilter] = useState({
        searchTerm: '',
        filterByDate: '',
        filterByType: '',
        filterByLocation: '',
        filterByPrice: ''
    });


    const searchDelaying = SearchDelay(searchFilter, 1000);

    useEffect(() => {
        setPageNumber(1);
        dispatch(searchByTitle(searchDelaying));
    }, [searchDelaying, dispatch])

    useEffect(() => {
        setPageNumber(1);
        dispatch(filterData(filterValues));
        //console.log(filterRetreatList);
    }, [filterValues, dispatch])

    const updateRetreatCountPerPage = () => {
        const width = window.innerWidth;
        if (width < 576) {
            setRetreatCountPerPage(3);
        } else if (width >= 576 && width < 900) {
            setRetreatCountPerPage(4);
        } else if (width >= 900 && width < 1000) {
            setRetreatCountPerPage(4);
        } else {
            setRetreatCountPerPage(3)
        }
    };

    useEffect(() => {
        updateRetreatCountPerPage();
        window.addEventListener('resize', updateRetreatCountPerPage);
        return () => {
            window.removeEventListener('resize', updateRetreatCountPerPage); // Clean up
        };
    }, []);

    // useEffect(() => {
    //     if(error != null){
    //         alert(error);
    //     }
    // }, [error]);

    return (

        <React.Fragment>

            <div className="retreat">

                <div className="retreat-filterDate">
                    <select aria-label="Filter by date" onChange={(event) => { setFilterValues({ ...filterValues, filterByDate: event.target.value }) }} >
                        <option value="" >Filter by Date</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                    </select>
                </div>

                <div className="retreat-filterType">
                    <select aria-label="Filter by type" onChange={(event) => { setFilterValues({ ...filterValues, filterByType: event.target.value }) }}>
                        <option value="" >Filter by Type</option>
                        <option value="Signature">Signature</option>
                        <option value="Standalone">Stand alone</option>
                    </select>
                </div>

                <div className="retreat-sort-by-price">
                    <select aria-label="Sort by price" onChange={(event) => { setFilterValues({ ...filterValues, filterByPrice: event.target.value }) }}>
                        <option value="" >Sort by Price</option>
                        <option value="low to high">Low to High</option>
                        <option value="high to low">Hight to Low</option>
                    </select>
                </div>

                <div className="retreat-filterByLocation">
                    <select aria-label="Filter by location" onChange={(event) => { setFilterValues({ ...filterValues, filterByLocation: event.target.value }) }}>
                        <option value="" >Filter by Location</option>
                        <option value="Goa">Goa</option>
                        <option value="Rishikesh">Rishikesh</option>
                        <option value="Kerala">Kerala</option>
                        <option value="Mumbai">Mumbai</option>
                        <option value="Delhi">Delhi</option>
                        <option value="Pune">Pune</option>
                        <option value="Chennai">Chennai</option>
                        <option value="Hyderabad">Hyderabad</option>
                        <option value="Varanasi">Varanasi</option>
                        <option value="Kolkata">Kolkata</option>
                        <option value="Agra">Agra</option>

                    </select>
                </div>

                <div className="retreat-search">
                    <input className="retreat-search-type" type="search" name="query" placeholder="Search retreats by title" onChange={(event) => setSearchFilter({ ...filterValues, searchTerm: event.target.value })} />
                </div>

            </div>

            <div className="retreat-component">

                {isLoading ?
                    (
                        <div className='retreat-no-records'>
                            <strong style={{fontSize: '30px', fontWeight: 400 }}>Fetching records...</strong>
                        </div>

                    ) : (
                        error !== null ? (
                            <div className='retreat-no-records'>
                                        <strong style={{ color: 'red', fontSize: '30px', fontWeight: 400 }}>An error occurred while fetching records. This might be due to network or server issues. Please check the console for detailed error information.</strong>
                                    </div>
                        ) : (
                            filterRetreatList.length === 0 ?
                                (
                                    <div className='retreat-no-records'>
                                        <strong style={{ fontSize: '30px', fontWeight: 400 }}>No records found. Please adjust your filters and try again.</strong>
                                    </div>
                                ) :
                                retreatsPerPage.map((retreat) => (
                                    <RetreatInfo retreat={retreat} key={retreat.id} />
                                ))
                        )
                            

                    )}

            </div>

            <div className="retreat-pagination">
                <button className="retreat-pagination-btn-previous " onClick={togglePreviousPage} disabled={pageNumber === 1} >Previous</button>
                <button className="retreat-pagination-btn-next" onClick={toggleNextPage} disabled={lastRetreatIndexofCurrentPage >= retreatLength}>Next</button>
            </div>

            <div className="retreat-copyright">
                <p className="retreat-copyright-text"> &#169; 2024 Wellness Retreats. All rights reserved.</p>
            </div>

        </React.Fragment>
    )
}

export default Retreats;