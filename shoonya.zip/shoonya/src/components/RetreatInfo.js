import './RetreatInfo.css';

function RetreatInfo(props) {

    const TimestampToDate = (timestamp) => {
        const date = new Date(timestamp * 1000);
        const options = { day: '2-digit', month: 'long', year: 'numeric' };
        return date.toLocaleDateString('en-US', options);
    }
    
    return (
        <div className="retreat-info">
            <div >
                <img className="retreat-info-img" src={props.retreat.image} alt={props.retreat.title} />
            </div>
            <div className="retreat-info-text">
                <span className="retreat-info-text1">{props.retreat.title}</span> <br></br>
                <span className="retreat-info-text2">{props.retreat.description}</span> <br></br>
                <span className="retreat-info-text3">Date: {TimestampToDate(props.retreat.date)}</span> <br></br>
                <span className="retreat-info-text4">Location: {props.retreat.location}</span> <br></br>
                <span className="retreat-info-text4">Price: ${props.retreat.price}</span> <br></br>
                <span className="retreat-info-text4">Type: {props.retreat.type}</span>
            </div>
        </div>
    )
}

export default RetreatInfo;